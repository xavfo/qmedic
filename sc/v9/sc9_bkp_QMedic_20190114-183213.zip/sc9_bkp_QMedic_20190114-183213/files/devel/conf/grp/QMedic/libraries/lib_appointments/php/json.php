<?php
	
$sql_lookup = "SELECT
   a.appointments_id,
   a_s.appointment_status_id,
   a_s.appointment_status_descr,
   s.staff_id,
   s.staff_name,
   a.appointment_start_date,
   a.appointment_start_time,
   a.appointment_end_date,
   a.appointment_end_time
FROM
   appointments a INNER JOIN appointment_status a_s ON a.current_status_id = a_s.appointment_status_id
   INNER JOIN staff s ON a.staff_id = s.staff_id";

if ( isset($_POST['opts']) ){
	$sql_lookup .= " WHERE a.current_status_id IN (".$_POST['opts'].")";
}

sc_lookup(ds , $sql_lookup, 'conn_mysql');



for($i = 0 ; $i < count({ds}) ; $i++){

   $idevento = {ds[$i][0]};
      
   $descricao = {ds[$i][4]};
      
   $datainicio = {ds[$i][5]};
      
   $horainicio = {ds[$i][6]};
      
   $datafim = {ds[$i][7]};	
      
   $horafim = {ds[$i][8]};
      
   $status = {ds[$i][1]};
	
   $staff = {ds[$i][3]};
      
   switch($status){
      
      case 1: $color = '#d29c0e';
      
      break;
   
      case 2: $color = '#20b2aa';
   
      break;
      
      case 3: $color = '#ff8080';
      
      break;
	   
	  case 4: $color = '#5d5d5d';
      
      break;
	   
	  case 5: $color = '#6db245';
      
      break;
   
   }      
   
   $resultado[] = array(
                  'id'     => $idevento ,
                  'title'  => utf8_encode($descricao) ,
                  'start'  => $datainicio . " " . $horainicio ,
                  'end'    => $datafim . " " . $horafim,
                  'allDay' => false,
                  'color'  => $color
               );
   
      
}

echo json_encode( $resultado);
	
?>