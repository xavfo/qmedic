<?php
//__NM__FUNCIONES DE SAMI__NM__FUNCTION__NM__//
	
//recibe dos fechas y calcula los dias que suceden entre fecha y fecha
function dias_transcurridos($fecha_i,$fecha_f)
{
	
	$dias	= (strtotime($fecha_i)-strtotime($fecha_f))/86400;
	$dias 	= abs($dias);
        $dias = floor($dias);		
	return $dias;
}

// INCREMENTA EN UN AÑO LA FECHA QUE SE ENVIA
function suma_anio ($fecha_new)
	{
	//echo "FECHA SIN SUMAR NADA DE NADA".$fecha_new;
	$nuevafecha = strtotime ( '+1 year' , strtotime ( $fecha_new ) ) ;
		//$nuevafecha = strtotime ( '-1 day' , strtotime ( $nuevafecha ) ) ;
		$nuevafecha = date ( 'Y-m-d' , $nuevafecha );
	
	return $nuevafecha;
	}
// OBTIENNE EL MES DE UNA FECHA DD/MM/AAAA
function obtiene_mes($fecha_mes)
	{
	$date = strtotime($fecha_mes);
	return date("m", $date);
	}

// OBTIENNE EL AÑO DE UNA FECHA DD/MM/AAAA
function obtiene_anio ($fecha_anio)
	{
	
	$date = strtotime($fecha_anio);
	return date("Y", $date);
	}

// OBTIENNE EL DIA DE UNA FECHA DD/MM/AAAA

function obtiene_dia ($fecha_dia)
	{
	$date = strtotime($fecha_dia);
	return date("d", $date);
	}
//CALCULO DEL PERIODO DEPENDIENTE DE LA FECHA DE INGRESO DEL EMPLEADO

function calcula_periodo ($periodo_new,$fecha_old)
	{
	
	//$periodo_old = "";
	
	 $dato = $periodo_new."-".obtiene_mes ($fecha_old)."-".obtiene_dia ($fecha_old);
	$fecha_actu = strtotime ( '-1 day' , strtotime ( $dato) ) ;
		//strtotime( $dato);
	 return date("Y-m-d",$fecha_actu);
		
	
}
	


function dias_vacaciones($dias_total)
	{
   
	$dias_calculados = floor($dias_total / 365);
	
if ($dias_calculados< 5)
	{
		// 15 DE VACACIONES SI SE TIENE MENOS DE 5 AÑOS
      $dias_vaca = 15;
     }
else {
       // SUMA LOS DIAS QUE DEBEN SER A PARTIR DEL 5 AÑO
	   $aux = $dias_calculados - 5;
		if ($aux > 15 )
			{
			// SI TIENE MAS DE 20 AÑOS EL TRABAJADOR EN LA COMPAÑIA
			$dias_vaca = 30;
		    }
	    else
			{
		    $dias_vaca = $aux + 15;
		   }
   }

return $dias_vaca;
}


	?>