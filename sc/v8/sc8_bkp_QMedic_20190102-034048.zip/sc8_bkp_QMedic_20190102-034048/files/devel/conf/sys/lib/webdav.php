<?php
//__NM__Funciones WebDav__NM__FUNCTION__NM__//

function exists($url, $user, $clave) {
		// WebDAV expects that checking a directory exists has a trailing slash
		if (substr($url, -1) != '/') {
			$url .= '/';
		}
		$credentials = array(
	    	$user,
	   	    $clave
        );
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PROPFIND');
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        curl_setopt($ch, CURLOPT_USERPWD, implode(':', $credentials));
		$res = curl_exec($ch);
		$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	    if ($code == 404) return false;
		if ($code == 200 || $code == 207) return true;
		user_error("Got error from webdav server - ".$code, E_USER_ERROR);
}
function mkdir($url, $user, $clave) {
		$credentials = array(
	    	$user,
	   	    $clave
        );
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'MKCOL');
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        curl_setopt($ch, CURLOPT_USERPWD, implode(':', $credentials));
		$res = curl_exec($ch);
		$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		return $code == 201;
	}
function borrar($url, $user, $clave) {
		$credentials = array(
	    	$user,
	   	    $clave
        );
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        curl_setopt($ch, CURLOPT_USERPWD, implode(':', $credentials));
		$res = curl_exec($ch);
		$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		return $code == 201;
	}
function put($handle, $url, $user, $clave) {
		$ch = curl_init($url);
	    $credentials = array(
	    	$user,
	   	    $clave
        );
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        curl_setopt($ch, CURLOPT_USERPWD, implode(':', $credentials));
		curl_setopt($ch, CURLOPT_PUT, true);
		curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
		curl_setopt($ch, CURLOPT_INFILE, $handle);
		$res = curl_exec($ch);
		fclose($handle);
		return curl_getinfo($ch, CURLINFO_HTTP_CODE);
	}
function upload_from_string($string, $url, $user, $clave) {
		$fh = tmpfile();
		fwrite($fh, $string);
		fseek($fh, 0);
		return put($fh, $url, $user, $clave);
	}
function upload_from_file($string, $url, $user, $clave) {
		put(fopen($string, 'rb'), $url, $user, $clave);
	}
function compartido($string, $url, $user, $clave) {
$credentials = array(
	    	$user,
	   	    $clave
        );
$fields = array(
	'path' => $string,
	'shareType' => '3'
			);

//url-ify the data for the POST
// foreach($fields as $key=>$value) 
// { 
//	$fields_string .= $key.'='.$value.'&'; 
// }
// rtrim($fields_string, '&');
$fields_string = "path=". $string ."&shareType=3";
//open connection
$ch = curl_init();
//set the url, number of POST vars, POST data
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
curl_setopt($ch, CURLOPT_USERPWD, implode(':', $credentials));
curl_setopt($ch,CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_POST, count($fields));
curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

// curl_setopt($ch, CURLOPT_POST, TRUE);
//  curl_setopt($ch, CURLOPT_POSTFIELDS, $msg);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
// curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
//execute post
$result = curl_exec($ch);
// $array = json_decode(trim($result), TRUE);
//close connection
curl_close($ch);
return $result;	

}
?>