SELECT
   paciente.pacienteCedula,
   paciente.pacienteNombre,
   paciente.pacienteApellido,
   genero.generoDescripcion,
   paciente.pacienteNacimiento,
   paciente.pacienteEmail,
   paciente.pacienteTelefono,
   certificado.certificadoFecha,
   certificado.certificadoContenido,
   certificado.certificadoAdjunto
FROM
   certificado, paciente, genero
WHERE
	certificado.idPaciente = paciente.idPaciente
   AND genero.idGenero = paciente.idGenero
   AND paciente.idPaciente = 1
ORDER BY
   certificado.idCertificado